//
//  _paisaTests.swift
//  5paisaTests
//
//  Created by Vishal22 Sharma on 18/02/22.
//

import XCTest
@testable import _paisa

class _paisaTests: XCTestCase {
    var viewModel = PDashboardContainerViewModel()
    var dashBoardViewModel = PDashboardViewModel()
    var viewModelFilter = PFilterViewModel()
    
    func test_getSchemes() {
        self.viewModel.getSchemeList(isSchaduledCall: true) { status in
            print(status)
        }
    }
    
    func test_getSchemesFromDb() {
        self.viewModel.getSchemesFromDb(isSchaduledCall: false) { status in
            print(status)
        }
    }
    
    func test_performFilterSort() {
        self.viewModel.filterAndSortData([.riskometer], sort: .nav) { status in
            print(status)
        }
    }
    
    func test_getSchemesFromServer() {
        self.viewModel.fetchSchemes { status in
            print(status)
        }
    }
    
    func test_StringToDouble() {
        let stringValue = "9.25"
        let doubleValue = stringValue.toDouble()
        print(doubleValue ?? 0)
    }
    
    func test_ViewConstraintsExtension() {
        let label = UILabel()
        let view = UIView()
        view.addSubview(label)
        view.addConstraintsWithFormatString(formate: "H:|[v0]|", views: label)
        
    }
    func test_checkObjAccess() {
        self.viewModelFilter.selectedSort = .nav
        self.viewModelFilter.selectedFilters = [.riskometer]
        print(self.viewModelFilter.filterArray)
        print(self.viewModelFilter.sortArray)
    }
}
