//
//  Constants.swift
//  5paisa
//
//  Created by Vishal22 Sharma on 23/02/22.
//

import Foundation
struct Constants {
    static let filterTitle = "Filters"
}
