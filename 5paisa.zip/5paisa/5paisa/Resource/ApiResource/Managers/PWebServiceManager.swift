//
//  PWebServiceManager.swift
//  5paisa
//
//  Created by Vishal22 Sharma on 18/02/22.
//

import Foundation

class PWebServiceManager {
    private let apiClient: APIClient!
    
    init(apiClient: APIClient) {
        self.apiClient = apiClient
    }
    func getSchemes(success: @escaping((SchemesResponseModel?) -> Void), failure: @escaping((Error?) -> Void)) {
        let resource = Resource(url: URL(string: "https://papi.indiainfoline.com/IIFL/MutualFund/data.svc/MFScreener-Filter-Schemes-version3-SebiCat/equity/4%2C5/open/growth/all/%5B5year%5D/1/30?type=all&schemefilter=all&ordercol=Ret5Y&sortorder=desc&responseType=json&businesstype=paisa")!)
        apiClient.load(resource) { (result) in
            switch result {
            case .success(let data):
                do {
                    let gitData = try JSONDecoder().decode(SchemesResponseModel.self, from: data)
                    success(gitData)                    
                } catch {
                    failure(error)
                }
            case .failure(let error):
                failure(error)
            }
        }
    }
}





