//
//  APIClient.swift
//  5paisa
//
//  Created by Vishal22 Sharma on 19/02/22.
//

import Foundation

// TODO: - Move to the separated file Resource.swift
struct Resource {
    let url: URL
    let method: String = "GET"
}

// TODO: - Move to the separated file GenericResult.swift
enum Result<T> {
    case success(T)
    case failure(Error)
}

enum APIClientError: Error {
    case noData
}

// TODO: - Move to the separated file URLRequest+Resource.swift
extension URLRequest {
    
    init(_ resource: Resource) {
        self.init(url: resource.url)
        self.httpMethod = resource.method
        self.setValue("Application/json", forHTTPHeaderField: "Content-Type")
        
        self.setValue("Basic aW5kaWFpbmZvbGluZVw1cGFuZHJvaWQ6MnhxUzV2L1g5Og==", forHTTPHeaderField: "Authorization")
        self.setValue("noauth", forHTTPHeaderField: "type")

    }
}

final class APIClient {
    
    func load(_ resource: Resource, result: @escaping ((Result<Data>) -> Void)) {
        let request = URLRequest(resource)
        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            guard let data = data else {
                result(.failure(APIClientError.noData))
                return
            }
            if let error = error {
                result(.failure(error))
                return
            }
            result(.success(data))
        }
        task.resume()
    }
    
}
