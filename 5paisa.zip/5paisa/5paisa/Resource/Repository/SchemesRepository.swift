//
//  SchemesRepository.swift
//  5paisa
//
//  Created by Vishal22 Sharma on 01/03/22.
//

import CoreData

protocol SchemesRepository {
    
    func create(schemeData: [SchemeData], completion: @escaping (Bool) -> Void)
    func getAll(completion: @escaping ([SchemesEntity]) -> Void)
   // func get(recommened flag: SchemesEntity.re) -> SchemesEntity
    // func update
    func deleteAllSchemes()
}

struct SchemesDataRepository: SchemesRepository {
    let schemeEntity = SchemesEntity(context: PPersistenceService.shared.context)
    func create(schemeData: [SchemeData], completion: @escaping (Bool) -> Void) {
        
        if schemeData.isEmpty {
            return
        }
        _ = schemeData.compactMap { obj -> SchemesEntity in
            let aum = obj.aum
            let amccode = obj.amccode
            let mfSchcode = obj.mfSchcode
            let schemeName = obj.schemeName
            let mainCode = obj.mainCode
            let schemeCategory = obj.schemeCategory
            let oneYear = obj.oneYear
            let threeYear = obj.threeYear
            let fiveYear = obj.fiveYear
            let inception = obj.inception
            let nav = obj.nav
            let perChange = obj.perChange
            let riskometervalue = obj.riskometervalue
            let recommenedFundFlag = obj.recommenedFundFlag
            let morningstaroverall = obj.morningstaroverall
            let subscriptionFlag = obj.subscriptionFlag
            let investment = obj.investment
            let groupCode = obj.groupCode
            let isin = obj.isin

            let scheme = SchemesEntity(context: PPersistenceService.shared.context)
            scheme.aum = aum
            scheme.amccode = amccode
            scheme.fiveYear = fiveYear
            scheme.groupCode = groupCode
            scheme.inception = inception
            scheme.investment = investment
            scheme.isin = isin
            scheme.mainCode = mainCode
            scheme.mf_schcode = mfSchcode
            scheme.morningstaroverall = morningstaroverall
            scheme.nav = nav
            scheme.oneYear = oneYear
            scheme.perChange = perChange
            scheme.recommenedFundFlag = recommenedFundFlag
            scheme.riskometervalue = riskometervalue
            scheme.schemeCategory = schemeCategory
            scheme.schemeName = schemeName
            scheme.subscriptionFlag = subscriptionFlag
            scheme.threeYear = threeYear
            return scheme
        }
        PPersistenceService.shared.saveContext()
        
        
        completion(true)
    }
    
    func getAll(completion: @escaping ([SchemesEntity]) -> Void) {
        
        let result = PPersistenceService.shared.fetchManagedObject(managedObject: SchemesEntity.self)
        
        completion(result ?? [])
    }
    
    func deleteAllSchemes() {
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "SchemesEntity")
        fetchRequest.returnsObjectsAsFaults = false
        do {
            let results = try PPersistenceService.shared.context.fetch(fetchRequest)
            for object in results {
                guard let objectData = object as? NSManagedObject else {continue}
                PPersistenceService.shared.context.delete(objectData)
            }
        } catch let error {
            print(error)
        }
    }
    
}
