//
//  PPersistantService.swift
//  5paisa
//
//  Created by Vishal22 Sharma on 19/02/22.
//

import Foundation
import CoreData
import UIKit

class PPersistenceService {
    
    private init() {}
    static let shared = PPersistenceService()
    lazy var context = persistentContainer.viewContext
    
    lazy var persistentContainer: NSPersistentContainer = {
        
        let container = NSPersistentContainer(name: "_paisa")
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error as NSError? {
                
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        })
        return container
    }()
    
    func saveContext() {
            if context.hasChanges {
                do {
                    try context.save()
                } catch {
                    let nserror = error as NSError
                    fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
                }
            }
        }

        func fetchManagedObject<T: NSManagedObject>(managedObject: T.Type) -> [T]?
        {
            do {
                guard let result = try PPersistenceService.shared.context.fetch(managedObject.fetchRequest()) as? [T] else {return nil}
                
                return result

            } catch let error {
                debugPrint(error)
            }

            return nil
        }
    
    func removeAllData(_ entity:String) {
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: entity)
        fetchRequest.returnsObjectsAsFaults = false
        do {
            let results = try context.fetch(fetchRequest)
            for object in results {
                guard let objectData = object as? NSManagedObject else {continue}
                context.delete(objectData)
            }
        } catch let error {
            print("Detele all data in \(entity) error :", error)
        }
    }
}
