//
//  SchemesEntity+CoreDataClass.swift
//  5paisa
//
//  Created by Vishal22 Sharma on 19/02/22.
//
//

import Foundation
import CoreData

@objc(SchemesEntity)
public class SchemesEntity: NSManagedObject {

}
