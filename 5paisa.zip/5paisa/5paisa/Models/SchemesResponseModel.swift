//
//  SchemesResponseModel.swift
//  5paisa
//
//  Created by Vishal22 Sharma on 18/02/22.
//

import Foundation

// MARK: - SchemesResponseModel
struct SchemesResponseModel: Codable {
    let response: Response
}

// MARK: - Response
struct Response: Codable {
    let type: String
    let data: DataClass
}

// MARK: - DataClass
struct DataClass: Codable {
    let schemelist: Schemelist
}

// MARK: - Schemelist
struct Schemelist: Codable {
    let recordcount: String
    let scheme: [SchemeData]
}

// MARK: - SchemeData
struct SchemeData: Codable {
    let amccode, mfSchcode, schemeName, mainCode: String
    let schemeCategory, oneYear, threeYear, fiveYear: String
    let inception, nav, perChange, riskometervalue: String
    let recommenedFundFlag: String
    let morningstaroverall: String?
    let subscriptionFlag, investment, aum, groupCode: String
    let isin: String

    enum CodingKeys: String, CodingKey {
        case amccode
        case mfSchcode = "mf_schcode"
        case schemeName = "SchemeName"
        case mainCode = "MainCode"
        case schemeCategory = "SchemeCategory"
        case oneYear = "OneYear"
        case threeYear = "ThreeYear"
        case fiveYear = "FiveYear"
        case inception
        case nav = "NAV"
        case perChange = "PerChange"
        case riskometervalue
        case recommenedFundFlag = "RecommenedFundFlag"
        case morningstaroverall
        case subscriptionFlag = "SubscriptionFlag"
        case investment
        case aum = "AUM"
        case groupCode = "GroupCode"
        case isin = "ISIN"
    }
}
