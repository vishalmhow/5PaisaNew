//
//  PFilterViewModel.swift
//  5paisa
//
//  Created by Vishal22 Sharma on 20/02/22.
//

import Foundation

class PFilterViewModel: NSObject {
    
    var filterArray: [SchemsFilter] = [.riskometer, .recommendedFund]
    var sortArray: [SchemsSort] = [.nav, .perChange, .aum]
    var selectedFilters = [SchemsFilter]()
    var selectedSort: SchemsSort?
}
