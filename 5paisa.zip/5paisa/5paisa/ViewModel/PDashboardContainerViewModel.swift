//
//  PDashboardViewModel.swift
//  5paisa
//
//  Created by Vishal22 Sharma on 19/02/22.
//

import Foundation
import CoreData

enum SchemsSort: String {
    case nav = "NAV (desc)"
    case perChange = "PerChange(desc)"
    case aum = "AUM(desc)"
}

enum SchemsFilter: String {
    case riskometer = "Riskometer value"
    case recommendedFund = "Recommended Fund Flag"
}

class PDashboardContainerViewModel: NSObject {
    
     let schemesRepository: SchemesDataRepository = SchemesDataRepository()
    
    
    let repository = PWebServiceManager(apiClient: APIClient())
    var schemesArray: SchemesResponseModel?
  //  let persistence = PPersistenceService.shared
    var schemeList = [SchemesEntity]()
    var selectedFilters = [SchemsFilter]()
    var selectedSort: SchemsSort?
    
    var dataArray = [SchemesEntity]()
    var dataArray1 = [SchemesEntity]()
    var dataArray2 = [SchemesEntity]()
    
    
    func getSchemeList(isSchaduledCall: Bool, completion: @escaping((Bool) -> Void)) {
        repository.getSchemes { response in
            self.schemesArray = response
            self.schemesRepository.deleteAllSchemes()
            self.schemesRepository.create(schemeData: self.schemesArray?.response.data.schemelist.scheme ?? []) { _ in
                        self.schemesRepository.getAll { (schemeList) in
                            self.dataArray = schemeList
                            self.dataArray1 = schemeList.filter { $0.investment == "Direct Plan" }
                            self.dataArray2 = schemeList.filter { $0.investment == "InDirect Plan" }
                            
                            if isSchaduledCall {
                                NotificationCenter.default.post(name: Notification.Name("NotificationIdentifier"), object: [self.dataArray,self.dataArray1,self.dataArray2])
                            }
                            completion(true)
                        }
            }
            
        } failure: { error in
            print(error!)
        }
    }
    
//    func getSchemeList(isSchaduledCall: Bool, completion: @escaping((Bool) -> Void)) {
//        repository.getSchemes { response in
//            self.schemesArray = response
//            self.schemesRepository.deleteAllSchemes()
//            self.schemesRepository.create(schemeData: self.schemesArray?.response.data.schemelist.scheme ?? []) { _ in
//                        self.schemesRepository.getAll { (schemeList) in
//                            self.dataArray = schemeList
//                            self.dataArray1 = schemeList.filter { $0.investment == "Direct Plan" }
//                            self.dataArray2 = schemeList.filter { $0.investment == "InDirect Plan" }
//
//                            if isSchaduledCall {
//                                NotificationCenter.default.post(name: Notification.Name("NotificationIdentifier"), object: [self.dataArray,self.dataArray1,self.dataArray2])
//                            }
//                            completion(true)
//                        }
//            }
//
//        } failure: { error in
//            print(error!)
//        }
//    }
    
    func fetchSchemes(completion: @escaping((Bool) -> Void)) {
        if self.dataArray.isEmpty {
            self.getSchemeList(isSchaduledCall: false) { status in
                if status {
                    self.schemesRepository.getAll { (schemeList) in
                        self.dataArray = schemeList
                        self.dataArray1 = schemeList.filter { $0.investment == "Direct Plan" }
                        self.dataArray2 = schemeList.filter { $0.investment == "InDirect Plan" }
                        completion(true)
                    }
                }
            }
        } else {
            self.schemesRepository.getAll() { (schemeList) in
                self.schemeList = []
                self.schemeList = schemeList
                completion(true)
            }
        }

    }
    
    func getSchemesFromDb(isSchaduledCall: Bool, completion: @escaping((Bool) -> Void)) {
        self.schemesRepository.getAll() { (schemeList) in
  
            if isSchaduledCall {
                self.getSchemeList(isSchaduledCall: isSchaduledCall) { status in
                    if status {
                        self.schemesRepository.getAll { (schemeList) in
                            self.dataArray = schemeList
                            self.dataArray1 = schemeList.filter { $0.investment == "Direct Plan" }
                            self.dataArray2 = schemeList.filter { $0.investment == "InDirect Plan" }
                            completion(true)
                        }
                    }
                }
            }
            
            if schemeList.count > 2 {
                
                self.dataArray = schemeList
                self.dataArray1 = schemeList.filter { $0.investment == "Direct Plan" }
                self.dataArray2 = schemeList.filter { $0.investment == "InDirect Plan" }
                
                completion(true)
            
            }
                
             else {
                self.getSchemeList(isSchaduledCall: true) { status in
                    if status {
                        self.schemesRepository.getAll { (schemeList) in
                            self.dataArray = schemeList
                            self.dataArray1 = schemeList.filter { $0.investment == "Direct Plan" }
                            self.dataArray2 = schemeList.filter { $0.investment == "InDirect Plan" }
                            completion(true)
                        }
                    }
                }
            
        }
        }
    }

    func filterAndSortData(_ filterArray: [SchemsFilter], sort: SchemsSort?, completion: @escaping((Bool) -> Void)) {
        
        var filteredDataArray = [SchemesEntity]()
        var schemsToBeFiltered = [SchemesEntity]()
        schemsToBeFiltered = self.dataArray
        
        
        for index in filterArray {
            switch index {
            case .riskometer:
                filteredDataArray = schemsToBeFiltered.filter {$0.riskometervalue == "Very High"}
            case .recommendedFund:
                filteredDataArray = schemsToBeFiltered.filter {$0.recommenedFundFlag == "Y"}
            }
        }
        if !filteredDataArray.isEmpty {
            schemsToBeFiltered = filteredDataArray
        }
        
        switch sort {
        case .nav:
            filteredDataArray = schemsToBeFiltered.sorted(by: { $0.nav?.toDouble() ?? 0 > $1.nav?.toDouble() ?? 0 })
        case .perChange:
            filteredDataArray = schemsToBeFiltered.sorted(by: { $0.perChange?.toDouble() ?? 0 > $1.perChange?.toDouble() ?? 0 })
        case .aum:
            filteredDataArray = schemsToBeFiltered.sorted(by: { $0.aum?.toDouble() ?? 0 > $1.aum?.toDouble() ?? 0 })
        default:
            print("Nothing")
        }
        
        if !filteredDataArray.isEmpty {
            NotificationCenter.default.post(name: Notification.Name("NotificationIdentifier"), object: filteredDataArray)
        }
        
        
        completion(true)
        
    }
}
