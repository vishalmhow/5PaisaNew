//
//  ViewController.swift
//  5paisa
//
//  Created by Vishal22 Sharma on 18/02/22.
//

import UIKit


class PLoginViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.setHidesBackButton(true, animated: false)
    }
    
    @IBAction func loginButttonTapped(_ sender: Any) {
    }
}




