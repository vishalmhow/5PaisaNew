//
//  PDashboardViewController.swift
//  5paisa
//
//  Created by Vishal22 Sharma on 18/02/22.
//

import UIKit

class PDashboardViewController: UIViewController {
    var viewModel = PDashboardViewModel()
    @IBOutlet weak var messageLabel: UILabel!
    @IBOutlet weak var schemeTableView: UITableView!
    let refreshControl = UIRefreshControl()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        NotificationCenter.default.addObserver(self, selector: #selector(self.methodOfReceivedNotification(notification:)), name: Notification.Name("NotificationIdentifier"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(self.schaduledApiCallTriggered(notification:)), name: Notification.Name("SchaduledApiCallTriggered"), object: nil)
        self.conditionToHideTableView()
    }
    @objc func methodOfReceivedNotification(notification: Notification) {
        self.viewModel.formateFilteredData(notification: notification) { status in
            if status {
                DispatchQueue.main.async {
                    self.schemeTableView.reloadData()
                }
            }
        }
    }
    
    
    @objc func schaduledApiCallTriggered(notification: Notification) {
        self.viewModel.dataArray = [SchemesEntity]()
        self.viewModel.dataArray1 = [SchemesEntity]()
        self.viewModel.dataArray2 = [SchemesEntity]()
        self.schemeTableView.reloadData()
    }
    
    
    
    func conditionToHideTableView() {
        switch self.viewModel.pageIndex {
        case 0:
            if self.viewModel.dataArray.isEmpty {
                self.schemeTableView.isHidden = true
            }
            
        case 1:
            if self.viewModel.dataArray1.isEmpty {
                self.schemeTableView.isHidden = true
            }
        case 2:
            if self.viewModel.dataArray2.isEmpty {
                self.schemeTableView.isHidden = true
            }
        default:
            self.schemeTableView.reloadData()
        }
    }
}

extension PDashboardViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch self.viewModel.pageIndex {
        case 0:
            return self.viewModel.dataArray.count
        case 1:
            return self.viewModel.dataArray1.count
        case 2:
            return self.viewModel.dataArray2.count
            
        default:
            return self.viewModel.dataArray.count
        }
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? PSchemeCell else {
            return UITableViewCell()
        }
        switch self.viewModel.pageIndex {
        case 0:
            cell.configureSummary(schemeModel: self.viewModel.dataArray[indexPath.row])
        case 1:
            cell.configureSummary(schemeModel: self.viewModel.dataArray1[indexPath.row])
        case 2:
            cell.configureSummary(schemeModel: self.viewModel.dataArray2[indexPath.row])
        default:
            cell.configureSummary(schemeModel: self.viewModel.dataArray[indexPath.row])
        }
        return cell
    }
}
